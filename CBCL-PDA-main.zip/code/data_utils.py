import csv
import numpy as np
import torch
import random
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc, precision_recall_curve


def read_csv(path):
    """读取CSV文件为FloatTensor"""
    with open(path, 'r', newline='') as f:
        reader = csv.reader(f)
        return torch.FloatTensor([[float(i) for i in row] for row in reader])


def create_kfold_split(association_matrix, n_splits=5, random_state=42):
    """创建K折交叉验证划分

    Args:
        association_matrix: 关联矩阵
        n_splits: 折数
        random_state: 随机种子

    Returns:
        splits: 每折的(train_mask, test_mask)列表
    """
    np.random.seed(random_state)
    torch.manual_seed(random_state)

    pos_idx = np.array([(i, j) for i in range(association_matrix.shape[0])
                        for j in range(association_matrix.shape[1]) if association_matrix[i, j] == 1])
    neg_idx = np.array([(i, j) for i in range(association_matrix.shape[0])
                        for j in range(association_matrix.shape[1]) if association_matrix[i, j] == 0])
    np.random.shuffle(neg_idx)

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    splits = []
    neg_start = 0

    for fold, (train_idx, test_idx) in enumerate(kf.split(pos_idx)):
        train_pos = pos_idx[train_idx]
        test_pos = pos_idx[test_idx]

        train_neg = neg_idx[neg_start:neg_start + len(train_pos)]
        neg_start += len(train_pos)
        test_neg = neg_idx[neg_start:neg_start + len(test_pos)]
        neg_start += len(test_pos)

        train_mask = np.zeros(association_matrix.shape)
        test_mask = np.zeros(association_matrix.shape)

        for i, j in train_pos:
            train_mask[i, j] = 1
        for i, j in train_neg:
            train_mask[i, j] = -1
        for i, j in test_pos:
            test_mask[i, j] = 1
        for i, j in test_neg:
            test_mask[i, j] = -1

        splits.append((train_mask, test_mask))

    return splits


def calculate_performance(test_num, pred_y, labels):
    """计算分类性能指标

    Args:
        test_num: 样本数
        pred_y: 预测标签
        labels: 真实标签

    Returns:
        acc, precision, sensitivity, specificity, mcc, f1
    """
    tp = fp = tn = fn = 0
    for i in range(test_num):
        if labels[i] == 1:
            if pred_y[i] == 1:
                tp += 1
            else:
                fn += 1
        else:
            if pred_y[i] == 0:
                tn += 1
            else:
                fp += 1

    acc = (tp + tn) / test_num if test_num > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0

    if (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn) > 0:
        mcc = (tp * tn - fp * fn) / np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    else:
        mcc = 0

    f1 = 2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) > 0 else 0

    return acc, precision, sensitivity, specificity, mcc, f1


def transfer_label_from_prob(proba, threshold=0.5):
    """将概率转换为标签"""
    return [1 if p >= threshold else 0 for p in proba]


def set_seed(seed=42):
    """设置随机种子"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)


def find_best_threshold(y_prob, y_test):
    """寻找最佳分类阈值，使敏感度和特异度最接近

    Args:
        y_prob: 预测概率
        y_test: 真实标签

    Returns:
        best_thresh: 最佳阈值
        best_balance: 最佳平衡度
    """
    best_thresh, best_balance = 0.5, float('inf')
    for thresh in np.arange(0.3, 0.8, 0.05):
        y_pred_tmp = [1 if p >= thresh else 0 for p in y_prob]
        tp = sum(1 for i in range(len(y_test)) if y_test[i] == 1 and y_pred_tmp[i] == 1)
        fp = sum(1 for i in range(len(y_test)) if y_test[i] == 0 and y_pred_tmp[i] == 1)
        fn = sum(1 for i in range(len(y_test)) if y_test[i] == 1 and y_pred_tmp[i] == 0)
        tn = sum(1 for i in range(len(y_test)) if y_test[i] == 0 and y_pred_tmp[i] == 0)
        sen = tp / (tp + fn) if (tp + fn) > 0 else 0
        spec = tn / (tn + fp) if (tn + fp) > 0 else 0
        balance = abs(sen - spec)
        if balance < best_balance:
            best_balance, best_thresh = balance, thresh
    return best_thresh, best_balance


def calculate_auc_aupr(y_test, y_prob):
    """计算AUC和AUPR

    Args:
        y_test: 真实标签
        y_prob: 预测概率

    Returns:
        auc_score, aupr_score
    """
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    auc_score = auc(fpr, tpr)
    prec_curve, rec_curve, _ = precision_recall_curve(y_test, y_prob)
    aupr = auc(rec_curve, prec_curve)
    return auc_score, aupr