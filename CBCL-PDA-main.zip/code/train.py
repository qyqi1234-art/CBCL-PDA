import numpy as np
import torch
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


# 训练超参数
EPOCHS = 50
LR = 1e-3
FOCAL_ALPHA = 0.2
FOCAL_GAMMA = 2.0
LAMBDA_CONTRA = 0.1


def train_model(model, optimizer, p_features, d_features, adjacency, train_mask, epochs=50):
    """训练GCN-Transformer模型

    Args:
        model: GCNTransformer模型实例
        optimizer: 优化器
        p_features: 蛋白质特征
        d_features: 药物特征
        adjacency: 邻接矩阵
        train_mask: 训练掩码，形状为 [n_p_subgraph, n_d_subgraph]
        epochs: 训练轮数
    """
    pos_mask = (train_mask == 1)
    neg_mask = (train_mask == -1)

    print("Epoch: ", end="")
    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad()

        p_final, d_final, loss_contra, entropy = model(p_features, d_features, adjacency)
        pred_scores = torch.sigmoid(p_final.mm(d_final.t()))

        valid_mask = (train_mask != 0)
        valid_scores = pred_scores[valid_mask]
        valid_labels = pos_mask[valid_mask].float()

        bce = F.binary_cross_entropy(valid_scores, valid_labels, reduction='none')
        pt = torch.where(valid_labels == 1, valid_scores, 1 - valid_scores)
        focal_weight = (1 - pt) ** FOCAL_GAMMA
        alpha_weight = torch.where(valid_labels == 1, FOCAL_ALPHA, 1 - FOCAL_ALPHA)
        loss_cls = (alpha_weight * focal_weight * bce).mean()

        loss = loss_cls + LAMBDA_CONTRA * loss_contra + 0.01 * entropy

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if epoch in [1, 10, 20, 30, 40, 50]:
            print(f"{epoch}/{epochs}={loss.item():.4f} ", end="")
    print()


def select_reliable_negatives(association_matrix, p_feat1, p_feat2, d_feat1, d_feat2,
                               train_mask, spy_ratio=0.1, safety_factor=0.9, random_state=42):
    """使用Spy技术选择可靠负样本

    Args:
        association_matrix: 完整的关联矩阵
        p_feat1, p_feat2: 蛋白质特征
        d_feat1, d_feat2: 药物特征
        train_mask: 训练掩码
        spy_ratio: 间谍样本比例
        safety_factor: 安全因子
        random_state: 随机种子

    Returns:
        更新后的训练掩码
    """
    np.random.seed(random_state)
    pos_idx = np.argwhere(train_mask == 1)
    unlabeled_idx = np.argwhere(train_mask == -1)

    n_spy = max(1, int(len(pos_idx) * spy_ratio))
    spy_idx = np.random.choice(len(pos_idx), n_spy, replace=False)
    spy_indices = pos_idx[spy_idx]
    remaining_pos = np.delete(pos_idx, spy_idx, axis=0)

    n_sample_u = len(remaining_pos)
    sampled_u_idx = np.random.choice(len(unlabeled_idx), min(n_sample_u, len(unlabeled_idx)), replace=False)
    sampled_u = unlabeled_idx[sampled_u_idx]

    def extract_features(i, j):
        return np.concatenate([
            p_feat1[i].cpu().numpy(), p_feat2[i].cpu().numpy(),
            d_feat1[j].cpu().numpy(), d_feat2[j].cpu().numpy()
        ])

    X_train = np.array([extract_features(i, j) for i, j in remaining_pos] +
                       [extract_features(i, j) for i, j in sampled_u])
    y_train = np.array([1] * len(remaining_pos) + [0] * len(sampled_u))

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)

    clf = LogisticRegression(max_iter=1000, random_state=random_state)
    clf.fit(X_train, y_train)

    X_all_u = scaler.transform([extract_features(i, j) for i, j in unlabeled_idx])
    X_spy = scaler.transform([extract_features(i, j) for i, j in spy_indices])

    spy_scores = clf.predict_proba(X_spy)[:, 1]
    all_u_scores = clf.predict_proba(X_all_u)[:, 1]

    threshold = max(np.min(spy_scores) * safety_factor, 0.05)
    rn_candidates = unlabeled_idx[all_u_scores < threshold]

    min_rn = int(len(pos_idx) * 0.3)
    if len(rn_candidates) < min_rn:
        extra = min_rn - len(rn_candidates)
        extra_idx = np.argsort(all_u_scores)[:extra]
        rn_indices = np.concatenate([rn_candidates, unlabeled_idx[extra_idx]])
    else:
        rn_indices = rn_candidates

    new_mask = np.zeros_like(train_mask, dtype=float)
    for i, j in pos_idx:
        new_mask[i, j] = 1
    for i, j in rn_indices:
        new_mask[i, j] = -1

    return new_mask


def build_heterogeneous_graph_inductive(p_feat1, p_feat2, d_feat1, d_feat2,
                                         association_matrix, data_mask):
    """构建严格Inductive异构图，只包含data_mask中标记的节点

    Args:
        p_feat1, p_feat2: 蛋白质特征
        d_feat1, d_feat2: 药物特征
        association_matrix: 关联矩阵
        data_mask: 数据掩码

    Returns:
        pi_features: 蛋白质子图特征
        d_features: 药物子图特征
        full_adj: 完整邻接矩阵
        mapping: 节点映射信息
    """
    association_matrix = association_matrix.cpu()
    data_mask = data_mask.cpu()

    involved_pi = set()
    involved_d = set()
    for i in range(association_matrix.shape[0]):
        for j in range(association_matrix.shape[1]):
            if data_mask[i, j] != 0:
                involved_pi.add(i)
                involved_d.add(j)

    pi_list = sorted(involved_pi)
    d_list = sorted(involved_d)
    pi_map = {old_idx: new_idx for new_idx, old_idx in enumerate(pi_list)}
    d_map = {old_idx: new_idx for new_idx, old_idx in enumerate(d_list)}

    n_pi = len(pi_list)
    n_d = len(d_list)

    zt5 = torch.zeros(56, 16, device=d_feat2.device)
    d_feat2_padded = torch.cat((d_feat2, zt5), dim=1)

    pi_raw_full = torch.cat((p_feat1, p_feat2), dim=1)
    d_raw_full = torch.cat((d_feat1, d_feat2_padded), dim=1)

    pi_features = pi_raw_full[pi_list]
    d_features = d_raw_full[d_list]

    pi_sim_full = torch.eye(p_feat1.shape[0])
    for i in range(p_feat1.shape[0]):
        if i not in involved_pi:
            pi_sim_full[i, :] = 0
            pi_sim_full[:, i] = 0
    pi_sim = pi_sim_full[pi_list][:, pi_list]

    d_sim = torch.eye(n_d)

    aso_pos = torch.zeros(n_pi, n_d)
    for i in range(association_matrix.shape[0]):
        for j in range(association_matrix.shape[1]):
            if data_mask[i, j] == 1 and i in pi_map and j in d_map:
                aso_pos[pi_map[i], d_map[j]] = 1

    upper = torch.cat((pi_sim, aso_pos), dim=1)
    lower = torch.cat((aso_pos.t(), d_sim), dim=1)
    full_adj = torch.cat((upper, lower), dim=0)

    mapping = {
        'pi_map': pi_map,
        'd_map': d_map,
        'pi_list': pi_list,
        'd_list': d_list,
        'n_pi': n_pi,
        'n_d': n_d
    }

    return pi_features, d_features, full_adj, mapping


def prepare_inductive_data(association_matrix, p_embeddings, d_embeddings, data_mask, mapping):
    """根据映射准备Inductive数据

    Args:
        association_matrix: 关联矩阵
        p_embeddings: 蛋白质嵌入
        d_embeddings: 药物嵌入
        data_mask: 数据掩码
        mapping: 节点映射

    Returns:
        features: 特征数组
        labels: 标签列表
    """
    association_matrix = association_matrix.detach().cpu().numpy()
    data_mask = data_mask.detach().cpu().numpy()
    pi_map = mapping['pi_map']
    d_map = mapping['d_map']

    p_embeddings_cpu = p_embeddings.detach().cpu()
    d_embeddings_cpu = d_embeddings.detach().cpu()

    features, labels = [], []
    for i in range(association_matrix.shape[0]):
        for j in range(association_matrix.shape[1]):
            if data_mask[i, j] == 0:
                continue
            if i not in pi_map or j not in d_map:
                continue

            pi_idx = pi_map[i]
            d_idx = d_map[j]
            features.append(list(p_embeddings_cpu[pi_idx].numpy()) + list(d_embeddings_cpu[d_idx].numpy()))
            labels.append(1 if data_mask[i, j] == 1 else 0)

    return np.array(features), labels