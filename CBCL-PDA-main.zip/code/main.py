import numpy as np
import torch
from xgboost import XGBClassifier

from model import GCNTransformer
from train import (
    train_model, select_reliable_negatives,
    build_heterogeneous_graph_inductive, prepare_inductive_data, LR
)
from data_utils import (
    read_csv, create_kfold_split, calculate_performance,
    transfer_label_from_prob, set_seed, find_best_threshold, calculate_auc_aupr
)


def main():
    """主程序：执行Inductive设置的5折交叉验证"""
    set_seed(42)

    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

    aso_full = read_csv('../data/datahandle/output/association1.csv').to(device)
    pi_f1 = read_csv('./JACCARDsim_combined.csv').to(device)
    pi_f2 = read_csv('./Seqsim_combined.csv').to(device)
    d_f1 = read_csv('../data/datahandle/output/DisJaccardSimilarity1.csv').to(device)
    d_f2 = read_csv('../data/datahandle/output/disSSimilarity1.csv').to(device)

    cv_splits = create_kfold_split(aso_full.cpu(), n_splits=5, random_state=42)
    all_performance = []

    for fold, (train_mask_np, test_mask_np) in enumerate(cv_splits):
        print(f"\n=== Fold {fold + 1}/5 ===")

        train_mask = torch.FloatTensor(train_mask_np).to(device)
        test_mask = torch.FloatTensor(test_mask_np).to(device)

        # 1. 选择可靠负样本
        train_mask_rn = select_reliable_negatives(
            aso_full.cpu(), pi_f1, pi_f2, d_f1, d_f2,
            train_mask_np, random_state=42 + fold
        )
        train_mask_rn = torch.FloatTensor(train_mask_rn).to(device)

        # 2. 构建训练子图
        p_fea_train, d_fea_train, train_adj, train_mapping = build_heterogeneous_graph_inductive(
            pi_f1, pi_f2, d_f1, d_f2, aso_full, train_mask_rn
        )
        p_fea_train = p_fea_train.to(device)
        d_fea_train = d_fea_train.to(device)
        train_adj = train_adj.to(device)

        # 3. 构建子图尺寸的掩码
        n_p_train = train_mapping['n_pi']
        n_d_train = train_mapping['n_d']
        train_mask_sub = torch.zeros(n_p_train, n_d_train, device=device)
        pi_map = train_mapping['pi_map']
        d_map = train_mapping['d_map']
        for i in range(aso_full.shape[0]):
            for j in range(aso_full.shape[1]):
                if train_mask_rn[i, j] != 0 and i in pi_map and j in d_map:
                    train_mask_sub[pi_map[i], d_map[j]] = train_mask_rn[i, j]

        # 4. 训练模型
        model_net = GCNTransformer(
            p_fea_train.shape[1], d_fea_train.shape[1], 128, 0.1
        ).to(device)
        optimizer = torch.optim.AdamW(model_net.parameters(), lr=LR, weight_decay=0.01)
        train_model(
            model_net, optimizer, p_fea_train, d_fea_train,
            train_adj, train_mask_sub, epochs=50
        )

        # 5. 获取训练集嵌入
        model_net.eval()
        with torch.no_grad():
            p_emb_train, d_emb_train, _, _ = model_net(p_fea_train, d_fea_train, train_adj)

        # 6. 准备训练数据
        X_train, y_train = prepare_inductive_data(
            aso_full, p_emb_train, d_emb_train, train_mask_rn, train_mapping
        )

        # 7. 构建测试子图
        p_fea_test, d_fea_test, test_adj, test_mapping = build_heterogeneous_graph_inductive(
            pi_f1, pi_f2, d_f1, d_f2, aso_full, test_mask
        )
        p_fea_test = p_fea_test.to(device)
        d_fea_test = d_fea_test.to(device)
        test_adj = test_adj.to(device)

        # 8. 编码测试集节点
        with torch.no_grad():
            p_emb_test, d_emb_test, _, _ = model_net(p_fea_test, d_fea_test, test_adj)

        # 9. 准备测试数据
        X_test, y_test = prepare_inductive_data(
            aso_full, p_emb_test, d_emb_test, test_mask, test_mapping
        )

        # 10. 训练XGBoost并评估
        if len(X_train) == 0 or len(X_test) == 0:
            print("Warning: empty train or test set")
            continue

        idx = np.random.permutation(len(X_train))
        X_train, y_train = X_train[idx], np.array(y_train)[idx]
        idx = np.random.permutation(len(X_test))
        X_test, y_test = X_test[idx], np.array(y_test)[idx]

        clf = XGBClassifier(n_estimators=10, max_depth=4, random_state=42)
        clf.fit(X_train, y_train)

        y_prob = clf.predict_proba(X_test)[:, 1]

        best_thresh, _ = find_best_threshold(y_prob, y_test)
        y_pred = transfer_label_from_prob(y_prob, best_thresh)

        acc, prec, sen, spec, mcc, f1 = calculate_performance(len(y_test), y_pred, y_test)
        auc_score, aupr = calculate_auc_aupr(y_test, y_prob)

        all_performance.append([acc, prec, sen, spec, mcc, auc_score, aupr, f1])

        print(f"Test: ACC={acc:.4f} Prec={prec:.4f} Sen={sen:.4f} Spec={spec:.4f} "
              f"MCC={mcc:.4f} F1={f1:.4f} AUC={auc_score:.4f} AUPR={aupr:.4f}")

    mean_results = np.mean(all_performance, axis=0)
    std_results = np.std(all_performance, axis=0)

    print("\n" + "=" * 60)
    print("FINAL RESULTS (Inductive Setting - No Data Leakage)")
    print("=" * 60)
    metrics = ['ACC', 'Prec', 'Sen', 'Spec', 'MCC', 'AUC', 'AUPR', 'F1']
    for i, (m, s) in enumerate(zip(mean_results, std_results)):
        print(f"{metrics[i]:8s}: {m:.4f} ± {s:.4f}")
    print("=" * 60)


if __name__ == "__main__":
    main()