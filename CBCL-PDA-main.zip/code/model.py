import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# Transformer 超参数
TRANS_D_MODEL = 128
TRANS_NHEAD = 4
TRANS_NUM_LAYERS = 2
TRANS_DROPOUT = 0.1


class GraphConvolution(nn.Module):
    """图卷积层"""
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter("bias", None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / np.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.mm(adj, support)
        if self.bias is not None:
            return output + self.bias
        return output


class GCN(nn.Module):
    """图卷积网络，分别编码蛋白质和药物特征"""
    def __init__(self, p_feat_dim, d_feat_dim, n_hidden, dropout):
        super().__init__()
        self.linear_p = nn.Linear(p_feat_dim, n_hidden)
        self.linear_d = nn.Linear(d_feat_dim, n_hidden)
        self.gc1 = GraphConvolution(n_hidden, n_hidden)
        self.dropout = dropout

    def forward(self, p_feat, d_feat, adj):
        p_feat = self.linear_p(p_feat)
        d_feat = self.linear_d(d_feat)
        x = torch.vstack((p_feat, d_feat))
        x = torch.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, self.training)
        return x[:p_feat.size(0)], x[p_feat.size(0):]


class TransformerBranch(nn.Module):
    """Transformer编码分支"""
    def __init__(self, p_feat_dim, d_feat_dim):
        super().__init__()
        self.p_proj = nn.Linear(p_feat_dim, TRANS_D_MODEL)
        self.d_proj = nn.Linear(d_feat_dim, TRANS_D_MODEL)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=TRANS_D_MODEL, nhead=TRANS_NHEAD,
            dropout=TRANS_DROPOUT, batch_first=True)
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=TRANS_NUM_LAYERS)

    def forward(self, p_feat, d_feat):
        x = torch.cat([self.p_proj(p_feat), self.d_proj(d_feat)], dim=0)
        x = self.encoder(x.unsqueeze(0)).squeeze(0)
        n_p = p_feat.size(0)
        return x[:n_p], x[n_p:]


class BidirectionalContrastiveModule(nn.Module):
    """双向对比学习模块，对齐GCN和Transformer的表示"""
    def __init__(self, hidden_dim):
        super().__init__()
        self.gcn_to_trans = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim)
        )
        self.trans_to_gcn = nn.Sequential(
            nn.Linear(TRANS_D_MODEL, hidden_dim),
            nn.LayerNorm(hidden_dim)
        )
        self.temp = nn.Parameter(torch.tensor(0.5))

    def forward(self, p_gcn, d_gcn, p_trans, d_trans):
        p_gcn_proj = F.normalize(self.gcn_to_trans(p_gcn), dim=1)
        d_gcn_proj = F.normalize(self.gcn_to_trans(d_gcn), dim=1)
        p_trans_proj = F.normalize(self.trans_to_gcn(p_trans), dim=1)
        d_trans_proj = F.normalize(self.trans_to_gcn(d_trans), dim=1)

        gcn_all = torch.cat([p_gcn_proj, d_gcn_proj], dim=0)
        trans_all = torch.cat([p_trans_proj, d_trans_proj], dim=0)

        temp = torch.clamp(torch.abs(self.temp), 0.1, 1.0)

        scores1 = torch.mm(gcn_all, trans_all.t()) / temp
        labels = torch.arange(scores1.size(0), device=scores1.device)
        loss1 = (F.cross_entropy(scores1, labels) +
                 F.cross_entropy(scores1.t(), labels)) / 2

        scores2 = torch.mm(trans_all, gcn_all.t()) / temp
        loss2 = (F.cross_entropy(scores2, labels) +
                 F.cross_entropy(scores2.t(), labels)) / 2

        return (loss1 + loss2) / 2


class AttentionFusion(nn.Module):
    """基于注意力机制的特征融合模块"""
    def __init__(self, hidden_dim, trans_dim=128):
        super().__init__()
        self.W_gcn = nn.Linear(hidden_dim, hidden_dim)
        self.W_trans = nn.Linear(trans_dim, hidden_dim)
        self.W_att = nn.Linear(hidden_dim, hidden_dim // 2)
        self.q = nn.Parameter(torch.randn(hidden_dim // 2, 1))
        self.b_att = nn.Parameter(torch.zeros(hidden_dim // 2))

    def forward(self, gcn_embed, trans_embed):
        z_gcn = self.W_gcn(gcn_embed)
        z_trans = self.W_trans(trans_embed)
        s_gcn = torch.matmul(torch.tanh(self.W_att(z_gcn) + self.b_att), self.q)
        s_trans = torch.matmul(torch.tanh(self.W_att(z_trans) + self.b_att), self.q)
        scores = torch.cat([s_gcn, s_trans], dim=1)
        alpha = F.softmax(scores, dim=1)
        fused = alpha[:, 0:1] * z_gcn + alpha[:, 1:2] * z_trans
        entropy = -(alpha * torch.log(alpha + 1e-8)).sum(dim=1).mean()
        return fused, entropy


class GCNTransformer(nn.Module):
    """GCN-Transformer联合模型，用于蛋白质-药物关联预测"""
    def __init__(self, p_feat_dim, d_feat_dim, n_hidden=128, dropout=0.1):
        super().__init__()
        self.gcn = GCN(p_feat_dim, d_feat_dim, n_hidden, dropout)
        self.trans = TransformerBranch(p_feat_dim, d_feat_dim)
        self.gcn_proj = nn.Linear(n_hidden, n_hidden)
        self.trans_proj = nn.Linear(TRANS_D_MODEL, n_hidden)
        self.contra_module = BidirectionalContrastiveModule(n_hidden)
        self.p_fusion = AttentionFusion(n_hidden)
        self.d_fusion = AttentionFusion(n_hidden)
        self.classifier = nn.Sequential(
            nn.Linear(n_hidden, n_hidden),
            nn.LayerNorm(n_hidden),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(n_hidden, n_hidden // 2),
            nn.LayerNorm(n_hidden // 2),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(n_hidden // 2, n_hidden)
        )

    def forward(self, p_feat, d_feat, adj):
        p_gcn_raw, d_gcn_raw = self.gcn(p_feat, d_feat, adj)
        p_trans_raw, d_trans_raw = self.trans(p_feat, d_feat)
        p_gcn = self.gcn_proj(p_gcn_raw)
        d_gcn = self.gcn_proj(d_gcn_raw)
        p_trans = self.trans_proj(p_trans_raw)
        d_trans = self.trans_proj(d_trans_raw)
        loss_contra = self.contra_module(p_gcn, d_gcn, p_trans, d_trans)
        p_fused, p_entropy = self.p_fusion(p_gcn, p_trans)
        d_fused, d_entropy = self.d_fusion(d_gcn, d_trans)
        total_entropy = (p_entropy + d_entropy) / 2
        p_final = self.classifier(p_fused)
        d_final = self.classifier(d_fused)
        return p_final, d_final, loss_contra, total_entropy