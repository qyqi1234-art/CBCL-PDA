import torch
import torch.nn.functional as F
import csv
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from torch_geometric.nn import GCNConv, VGAE
from torch_geometric.data import Data
import os
import gc
import math


def read_csv_info(path):
    """获取CSV文件的基本信息"""
    print(f"正在读取CSV文件信息: {path}")
    if not os.path.exists(path):
        print(f"错误：文件不存在 - {path}")
        return None

    with open(path, 'r', newline='') as csv_file:
        reader = csv.reader(csv_file)
        first_row = next(reader)
        total_cols = len(first_row)

        # 计算总行数
        total_rows = 1
        for _ in reader:
            total_rows += 1

    print(f"CSV文件信息: {total_rows}行 x {total_cols}列")
    return total_rows, total_cols


def read_csv_batch(path, start_row, end_row, start_col, end_col):
    """读取CSV文件的指定批次"""
    print(f"正在读取CSV文件批次: 行[{start_row}:{end_row}], 列[{start_col}:{end_col}]")

    md_data = []
    with open(path, 'r', newline='') as csv_file:
        reader = csv.reader(csv_file)
        for i, row in enumerate(reader):
            if i < start_row:
                continue
            if i >= end_row:
                break
            # 只取指定列的数据
            batch_row = [float(row[j]) for j in range(start_col, min(end_col, len(row)))]
            md_data.append(batch_row)

    print(f"批次数据读取完成，大小: {len(md_data)}x{len(md_data[0]) if md_data else 0}")
    return torch.FloatTensor(md_data)


def get_edge_index(matrix_2, threshold=0.0):
    """构建边索引"""
    print("正在构建边索引...")
    nonzero_indices = torch.nonzero(matrix_2 > threshold, as_tuple=False)
    edge_index = nonzero_indices.t().contiguous()
    print(f"边索引构建完成，边数: {edge_index.size(1)}")
    return edge_index


def process_batch(path, batch_id, start_idx, end_idx, total_size):
    """处理单个批次的数据"""
    print(f"\n{'=' * 60}")
    print(f"处理批次 {batch_id}: 节点 {start_idx} - {end_idx}")
    print(f"{'=' * 60}")

    # 读取批次数据
    batch_matrix = read_csv_batch(path, start_idx, end_idx, start_idx, end_idx)
    if batch_matrix is None:
        return None

    print(f"批次矩阵大小: {batch_matrix.shape}")

    # KMeans聚类
    print("开始KMeans聚类...")
    y_pred = KMeans(n_clusters=3, random_state=9).fit_predict(batch_matrix)
    print(f"聚类完成，簇分布: {[np.sum(y_pred == i) for i in range(3)]}")

    # 转换为torch tensor
    y_pred_tensor = torch.from_numpy(y_pred)

    print("正在更新相似性矩阵...")
    # 更新矩阵权重
    for cluster_id in range(3):
        cluster_indices = torch.where(y_pred_tensor == cluster_id)[0]
        print(f"处理簇 {cluster_id}, 大小: {len(cluster_indices)}")

        # 向量化操作更新权重
        if len(cluster_indices) > 1:
            cluster_mask = torch.zeros_like(batch_matrix, dtype=torch.bool)
            cluster_mask[cluster_indices[:, None], cluster_indices[None, :]] = True
            cluster_mask.fill_diagonal_(False)  # 去除对角线

            batch_matrix[cluster_mask] *= 1.8

        # 清理内存
        gc.collect()

    print("矩阵更新完成")

    # 构建边索引
    edge_index = get_edge_index(batch_matrix)

    return batch_matrix, edge_index


def train_batch_model(data, batch_id, channels=16, epochs=50):
    """训练单个批次的模型"""
    print(f"\n开始训练批次 {batch_id} 的模型...")

    class GCNEncoder(torch.nn.Module):
        def __init__(self, in_channels, out_channels):
            super(GCNEncoder, self).__init__()
            self.conv1 = GCNConv(in_channels, out_channels)
            self.conv2 = GCNConv(out_channels, out_channels)
            self.conv_mu = GCNConv(out_channels, out_channels)
            self.conv_logvar = GCNConv(out_channels, out_channels)

        def forward(self, x, edge_index):
            x = F.relu(self.conv1(x, edge_index))
            x = F.relu(self.conv2(x, edge_index))
            mu = self.conv_mu(x, edge_index)
            logvar = self.conv_logvar(x, edge_index)
            return mu, logvar

    # 设置设备 - 优先使用GPU
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")

    # 初始化模型
    model = VGAE(GCNEncoder(data.x.shape[1], channels)).to(device)
    data = data.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    def train():
        model.train()
        optimizer.zero_grad()
        z = model.encode(data.x, data.edge_index)
        loss = model.recon_loss(z, data.edge_index)
        loss = loss + (1 / data.num_nodes) * model.kl_loss()
        loss.backward()
        optimizer.step()
        return loss.item()

    # 训练模型
    print(f"开始训练 {epochs} 个epoch...")
    for epoch in range(1, epochs + 1):
        loss = train()
        if epoch % 10 == 0:
            print(f'Batch {batch_id}, Epoch: {epoch:03d}, Loss: {loss:.4f}')

    # 获取最终编码
    model.eval()
    with torch.no_grad():
        z = model.encode(data.x, data.edge_index)
        final_output = z.cpu().detach().numpy()

    return final_output


def main():
    """主函数"""
    print("=" * 60)
    print("开始分批处理VGAE训练...")
    print("=" * 60)

    # 配置参数
    csv_path = '../data/datahandle/output/RNASeqSimilarity_clean.csv'
    num_batches = 3  # 分成3个批次
    channels = 64
    epochs = 50

    # 获取文件信息
    total_rows, total_cols = read_csv_info(csv_path)
    if total_rows is None:
        print("无法读取文件信息，程序退出")
        return

    # 计算批次大小
    batch_size = math.ceil(total_rows / num_batches)
    print(f"总数据大小: {total_rows}x{total_cols}")
    print(f"批次数: {num_batches}, 每批次大小: {batch_size}")

    # 存储所有批次的结果
    all_results = []
    batch_info = []

    # 处理每个批次
    for batch_id in range(num_batches):
        start_idx = batch_id * batch_size
        end_idx = min((batch_id + 1) * batch_size, total_rows)

        if start_idx >= total_rows:
            break

        try:
            # 处理批次数据
            batch_matrix, edge_index = process_batch(
                csv_path, batch_id + 1, start_idx, end_idx, total_rows
            )

            if batch_matrix is None:
                print(f"批次 {batch_id + 1} 处理失败，跳过")
                continue

            # 创建图数据
            data = Data(x=batch_matrix, edge_index=edge_index)
            print(f"批次 {batch_id + 1} 图数据: 节点数={data.num_nodes}, 边数={data.num_edges}")

            # 训练模型
            result = train_batch_model(data, batch_id + 1, channels, epochs)

            # 保存结果
            all_results.append(result)
            batch_info.append({
                'batch_id': batch_id + 1,
                'start_idx': start_idx,
                'end_idx': end_idx,
                'nodes': data.num_nodes,
                'edges': data.num_edges,
                'output_shape': result.shape
            })

            # 保存单个批次结果
            batch_df = pd.DataFrame(result)
            batch_df.to_csv(f'Seqsim_batch_{batch_id + 1}.csv', index=False)
            print(f"批次 {batch_id + 1} 结果已保存")

            # 清理内存
            del batch_matrix, edge_index, data, result
            gc.collect()

            # 清理GPU内存（如果使用GPU）
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                print(f"批次 {batch_id + 1} GPU内存已清理")

        except Exception as e:
            print(f"批次 {batch_id + 1} 处理出错: {str(e)}")
            continue

    # 合并所有结果
    if all_results:
        print("\n" + "=" * 60)
        print("合并所有批次结果...")
        print("=" * 60)

        # 垂直拼接所有结果
        combined_result = np.vstack(all_results)
        combined_df = pd.DataFrame(combined_result)
        combined_df.to_csv('Seqsim_combined.csv', index=False)

        print(f"合并完成！最终结果形状: {combined_result.shape}")
        print("结果已保存到 Seqsim_combined.csv")

        # 打印批次信息
        print("\n批次处理汇总:")
        for info in batch_info:
            print(f"批次 {info['batch_id']}: 行 {info['start_idx']}-{info['end_idx']}, "
                  f"节点 {info['nodes']}, 边 {info['edges']}, 输出 {info['output_shape']}")

    print("\n程序执行完成！")


if __name__ == "__main__":
    main()