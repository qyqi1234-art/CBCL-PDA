import pandas as pd
import numpy as np
from scipy.stats import spearmanr
from itertools import product
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm


def main():
    # 读取CSV文件
    print("读取RNA序列数据...")
    df = pd.read_csv("./output/unique_rnas.csv")

    # 不过滤空序列，但记录有效序列的数量
    valid_seq_count = df[df['sequence'].notna() & (df['sequence'] != "") & (df['sequence'].str.len() >= 3)].shape[0]
    print(f"总RNA序列数量: {len(df)}")
    print(f"有效RNA序列数量(长度>=3): {valid_seq_count}")

    # 生成所有可能的3-mer（仅使用RNA的4个核苷酸）
    nucleotides = ['A', 'C', 'G', 'U']  # 移除了T，因为RNA使用U而不是T
    all_kmers = [''.join(kmer) for kmer in product(nucleotides, repeat=3)]
    print(f"所有可能的3-mer数量: {len(all_kmers)}")  # 应该是64个(4^3)

    # 确保3-mer是有序的，便于后续操作
    all_kmers.sort()

    # 打印前几个3-mer示例
    print(f"3-mer示例: {all_kmers[:5]}...")

    # 为所有序列（包括空序列）创建默认的空频率向量
    default_freq_vector = {kmer: 0 for kmer in all_kmers}

    # 计算所有序列的3-mer频率
    print("计算所有序列的3-mer频率并构建64维向量...")
    frequency_vectors = []

    for idx, row in tqdm(df.iterrows(), total=len(df)):
        seq = str(row['sequence']) if pd.notna(row['sequence']) else ""

        # 将序列中的T转换为U（如果存在）
        seq = seq.replace('T', 'U')

        if len(seq) >= 3:  # 序列长度必须至少为3才能计算3-mer
            freq_vector = calculate_kmer_frequencies(seq, all_kmers, k=3)
        else:
            # 对于空序列或长度<3的序列，使用默认的零频率向量
            freq_vector = default_freq_vector.copy()

        frequency_vectors.append({
            'id': row['id'],
            'rna': row['rna'],
            'frequencies': freq_vector,
            'is_valid': len(seq) >= 3
        })

    print(f"成功为所有{len(frequency_vectors)}个序列生成了64维频率向量")

    # 计算相似性矩阵
    print("计算Spearman相关系数相似性矩阵...")
    n_sequences = len(frequency_vectors)

    # 初始化相似性矩阵
    similarity_matrix = np.zeros((n_sequences, n_sequences))

    # 计算上三角矩阵（对角线上的元素为1，矩阵是对称的）
    for i in tqdm(range(n_sequences)):
        similarity_matrix[i, i] = 1.0  # 对角线上的元素为1

        # 如果当前序列无效（空序列或长度<3），则跳过计算，保持默认值0
        if not frequency_vectors[i]['is_valid']:
            continue

        for j in range(i + 1, n_sequences):
            # 如果对应序列无效，则跳过计算，保持默认值0
            if not frequency_vectors[j]['is_valid']:
                continue

            # 计算Spearman相关系数 RS(pi, pj)
            corr = calculate_spearman_correlation(
                frequency_vectors[i]['frequencies'],
                frequency_vectors[j]['frequencies']
            )
            similarity_matrix[i, j] = corr
            similarity_matrix[j, i] = corr  # 矩阵是对称的

    # 将相似性矩阵保存到文件
    save_similarity_matrix(similarity_matrix, frequency_vectors)

    # 可视化相似性矩阵（如果序列数量较小）
    if n_sequences <= 100:
        is_valid = [v['is_valid'] for v in frequency_vectors]
        visualize_similarity_matrix(
            similarity_matrix,
            [v['rna'] for v in frequency_vectors],
            is_valid=is_valid
        )

    # 额外保存64维向量的样例（前10个序列）
    save_vector_examples(frequency_vectors[:10], all_kmers)

    print("完成！")


def calculate_kmer_frequencies(sequence, all_kmers, k=3):
    """计算序列中每个k-mer的频率，构建64维向量"""
    # 初始化所有可能k-mer的计数为0
    kmer_counts = {kmer: 0 for kmer in all_kmers}

    # 计算序列中每个k-mer的出现次数
    for i in range(len(sequence) - k + 1):
        kmer = sequence[i:i + k]
        if kmer in kmer_counts:
            kmer_counts[kmer] += 1

    # 计算频率（每个k-mer的计数 / 序列中k-mer的总数）
    total_kmers = max(1, len(sequence) - k + 1)  # 避免除以零
    kmer_frequencies = {kmer: count / total_kmers for kmer, count in kmer_counts.items()}

    return kmer_frequencies


def calculate_spearman_correlation(vector_a, vector_b):
    """计算两个piRNA序列的相似度RS(pi, pj)，使用Spearman相关系数"""
    # 确保向量以相同的顺序排列
    keys = sorted(vector_a.keys())
    values_a = [vector_a[key] for key in keys]
    values_b = [vector_b[key] for key in keys]

    # 检查向量是否都是零向量（或几乎是零向量）
    if np.allclose(values_a, np.zeros_like(values_a)) or np.allclose(values_b, np.zeros_like(values_b)):
        return 0.0  # 如果任一向量是零向量，相关系数默认为0

    # 如果向量中的值都相同，spearmanr会返回nan，此时我们返回1.0（如果两个向量相同）或0.0（如果不同）
    if len(set(values_a)) == 1 and len(set(values_b)) == 1:
        if values_a[0] == values_b[0]:
            return 1.0
        else:
            return 0.0

    # 计算Spearman相关系数
    try:
        corr, _ = spearmanr(values_a, values_b)
        # 处理nan结果
        if np.isnan(corr):
            return 0.0
        return corr
    except:
        # 如果计算出错，返回0
        return 0.0


def save_vector_examples(vectors, all_kmers):
    """保存64维向量的样例"""
    # 创建一个DataFrame，显示64维向量的前几个样例
    vector_examples = []
    for v in vectors:
        if v['is_valid']:
            # 将频率字典转换为排序后的列表
            freq_list = [v['frequencies'][kmer] for kmer in sorted(all_kmers)]
            vector_examples.append({
                'rna': v['rna'],
                'vector': freq_list
            })

    if vector_examples:
        # 保存为CSV格式
        vector_df = pd.DataFrame([{
            'rna': v['rna'],
            **{kmer: v['vector'][i] for i, kmer in enumerate(sorted(all_kmers))}
        } for v in vector_examples])

        vector_df.to_csv('./output/RNAVectorExamples.csv', index=False)
        print("64维向量样例已保存为: ./output/RNAVectorExamples.csv")


def save_similarity_matrix(matrix, freq_vectors):
    """将相似性矩阵保存到文件"""
    # 保存为NumPy数组（二进制格式，适合后续加载）
    np.save('./output/RNASeqSimilarity.npy', matrix)
    print("相似性矩阵已保存为: ./output/RNASeqSimilarity.npy")

    # 保存为CSV格式（可读文本格式）
    rna_ids = [v['rna'] for v in freq_vectors]

    # 创建带有RNA ID作为索引和列名的DataFrame
    similarity_df = pd.DataFrame(matrix, index=rna_ids, columns=rna_ids)

    # 保存为CSV
    similarity_df.to_csv('./output/RNASeqSimilarity.csv')
    print("相似性矩阵已保存为CSV格式: ./output/RNASeqSimilarity.csv")

    # 保存矩阵与RNA ID的映射，包括序列有效性信息
    id_mapping = pd.DataFrame([{
        'index': i,
        'id': v['id'],
        'rna': v['rna'],
        'is_valid': v['is_valid']
    } for i, v in enumerate(freq_vectors)])
    id_mapping.to_csv('./output/RNAmapping.csv', index=False)
    print("RNA ID映射已保存为: ./output/RNAmapping.csv")


def visualize_similarity_matrix(matrix, labels=None, n_clusters=None, is_valid=None):
    """可视化相似性矩阵"""
    # 如果提供了is_valid，则只可视化有效序列
    if is_valid is not None and not all(is_valid):
        valid_indices = [i for i, valid in enumerate(is_valid) if valid]
        if valid_indices:
            valid_matrix = matrix[np.ix_(valid_indices, valid_indices)]
            valid_labels = [labels[i] for i in valid_indices] if labels else None

            # 递归调用，但仅使用有效序列
            visualize_similarity_matrix(valid_matrix, valid_labels, n_clusters)

            # 额外可视化完整矩阵
            plt.figure(figsize=(12, 10))
            mask = np.zeros_like(matrix, dtype=bool)
            for i in range(len(matrix)):
                for j in range(len(matrix)):
                    if i not in valid_indices or j not in valid_indices:
                        mask[i, j] = True

            sns.heatmap(matrix, cmap='viridis', mask=mask,
                        xticklabels=labels, yticklabels=labels)
            plt.title('RNA序列相似性矩阵 (带空序列)')
            plt.tight_layout()
            plt.savefig('./output/RNASimilarityempty.png', dpi=300)
            plt.close()
            print("包含空序列的相似性矩阵热图已保存为: ./output/RNASimilarityempty.png")
            return

    plt.figure(figsize=(12, 10))

    # 使用聚类对矩阵进行排序（可选）
    if n_clusters:
        from scipy.cluster.hierarchy import linkage, fcluster, dendrogram
        from scipy.spatial.distance import squareform

        # 将相似性矩阵转换为距离矩阵
        distance_matrix = 1 - matrix
        # 将对称矩阵转换为压缩的距离向量
        condensed_dist = squareform(distance_matrix)
        # 层次聚类
        Z = linkage(condensed_dist, method='ward')
        # 根据聚类结果重新排序矩阵
        if labels:
            plt.figure(figsize=(10, 8))
            dendrogram(Z, labels=labels, leaf_rotation=90)
            plt.title('RNA序列的层次聚类')
            plt.tight_layout()
            plt.savefig('./output/RNAdendrogram.png', dpi=300)
            plt.close()

        # 获取新的排序
        clusters = fcluster(Z, n_clusters, criterion='maxclust')
        order = np.argsort(clusters)
        # 重新排序矩阵
        matrix = matrix[order, :][:, order]
        if labels:
            labels = [labels[i] for i in order]

    # 绘制热图
    sns.heatmap(matrix, cmap='viridis', xticklabels=labels, yticklabels=labels)
    plt.title('RNA序列相似性矩阵 (Spearman相关系数)')
    plt.tight_layout()
    plt.savefig('./output/RNASeqSimilarity.png', dpi=300)
    print("相似性矩阵热图已保存为: ./output/RNASeqSimilarity.png")


if __name__ == "__main__":
    main()