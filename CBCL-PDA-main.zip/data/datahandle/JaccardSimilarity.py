import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform
from tqdm import tqdm  # For progress tracking
import matplotlib.pyplot as plt
import seaborn as sns


# Function to calculate Jaccard similarity matrix
def calculate_jaccard_similarity(binary_matrix):
    """
    Calculate Jaccard similarity matrix from a binary matrix.

    Parameters:
    binary_matrix (numpy.ndarray): Binary matrix where rows are entities and
                                  columns are features

    Returns:
    numpy.ndarray: Jaccard similarity matrix
    """
    n_samples = binary_matrix.shape[0]
    jaccard_sim = np.zeros((n_samples, n_samples))

    # Calculate Jaccard similarity for each pair
    for i in tqdm(range(n_samples)):
        for j in range(i, n_samples):
            # Get the binary vectors for the two entities
            vec_i = binary_matrix[i]
            vec_j = binary_matrix[j]

            # Calculate intersection and union
            intersection = np.sum(np.logical_and(vec_i, vec_j))
            union = np.sum(np.logical_or(vec_i, vec_j))

            # Calculate Jaccard similarity (handle division by zero)
            if union == 0:
                jaccard_sim[i, j] = 0
            else:
                jaccard_sim[i, j] = intersection / union

            # Matrix is symmetric
            jaccard_sim[j, i] = jaccard_sim[i, j]

    return jaccard_sim


def main():
    # Load the data
    print("Loading data...")
    df = pd.read_csv('./output/association_matrix_full.csv')

    # Extract disease names for reference
    # disease_ids = df['Disease ID'].values
    disease_names = df['Disease Name'].values

    # Extract the association matrix (binary values)
    # We'll remove the first two columns (Disease ID and Disease Name)
    rna_columns = [col for col in df.columns if col.startswith('RNA_')]
    association_matrix = df[rna_columns].values

    # Convert to binary if not already (just to be safe)
    association_matrix = (association_matrix > 0).astype(int)

    print(f"Association matrix shape: {association_matrix.shape}")

    # Calculate Jaccard similarity matrix for diseases
    print("Calculating disease similarity matrix...")
    disease_similarity = calculate_jaccard_similarity(association_matrix)

    # Calculate Jaccard similarity matrix for RNAs
    print("Calculating RNA similarity matrix...")
    # Transpose the matrix to have RNAs as rows
    rna_similarity = calculate_jaccard_similarity(association_matrix.T)

    # Create DataFrame for disease similarity with proper labels
    disease_sim_df = pd.DataFrame(
        disease_similarity,
        index=disease_names,
        columns=disease_names
    )

    # Create DataFrame for RNA similarity with proper labels
    rna_sim_df = pd.DataFrame(
        rna_similarity,
        index=rna_columns,
        columns=rna_columns
    )

    # Save the similarity matrices to CSV files
    print("Saving results...")
    disease_sim_df.to_csv('./output/DisJaccardSimilarity.csv')

    # The RNA similarity matrix might be very large, so we'll save it in chunks or in a compressed format
    # if rna_similarity.shape[0] > 1000:
    #     print("RNA similarity matrix is large. Saving in compressed format...")
    #     pd.DataFrame(rna_similarity).to_csv('RNAJaccardSimilarity.csv.gz', compression='gzip')
    # else:
    rna_sim_df.to_csv('./output/RNAJaccardSimilarity.csv')

    # Optional: Visualize a portion of the disease similarity matrix
    plt.figure(figsize=(10, 8))
    sns.heatmap(disease_sim_df.iloc[:20, :20], annot=False, cmap='viridis')
    plt.title('Disease Jaccard Similarity Matrix (First 20)')
    plt.tight_layout()
    plt.savefig('./output/DisJaccardSimilarity_heatmap.png')

    print("Done!")


if __name__ == "__main__":
    main()