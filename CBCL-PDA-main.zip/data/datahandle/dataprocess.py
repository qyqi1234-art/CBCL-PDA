import pandas as pd
import numpy as np
import os


def process_rna_disease_data(file_path):
    """
    处理RNA-疾病数据，筛选人类相关数据，去重并构建关联矩阵

    参数:
    file_path (str): RNA疾病Excel文件路径

    返回:
    tuple: (rna_df, disease_df, association_matrix)
    """
    print("开始处理数据...")

    # 读取Excel文件
    df = pd.read_excel(file_path)
    print(f"原始数据总行数: {len(df)}")

    # 筛选人类相关数据
    human_df = df[df['specise'] == 'Homo sapiens']
    print(f"人类相关数据总行数: {len(human_df)}")

    # 筛选DO ID不为空的数据
    human_df_valid = human_df[human_df['DO ID'].notna() & (human_df['DO ID'] != '')]
    print(f"有效DO ID的数据总行数: {len(human_df_valid)}")
    print(f"删除了 {len(human_df) - len(human_df_valid)} 条DO ID为空的数据")

    # 去重RNA和疾病
    unique_rnas = list(human_df_valid['RNA Symbol'].unique())
    disease_do_pairs = human_df_valid[['Disease Name', 'DO ID']].drop_duplicates()
    unique_diseases = list(disease_do_pairs['Disease Name'].unique())

    print(f"去重后的RNA数量: {len(unique_rnas)}")
    print(f"去重后的疾病数量: {len(unique_diseases)}")

    # 创建RNA表
    rna_df = pd.DataFrame({
        'id': range(1, len(unique_rnas) + 1),
        'rna': unique_rnas
    })

    # 创建疾病表
    disease_df = pd.DataFrame({
        'id': range(1, len(unique_diseases) + 1),
        'disease': unique_diseases
    })

    # 添加DO ID
    disease_df = disease_df.merge(
        disease_do_pairs,
        left_on='disease',
        right_on='Disease Name',
        how='left'
    )
    disease_df = disease_df[['id', 'disease', 'DO ID']]

    # 验证所有疾病都有DO ID
    empty_do_ids = disease_df[disease_df['DO ID'].isna() | (disease_df['DO ID'] == '')]
    if not empty_do_ids.empty:
        print(f"警告：仍有 {len(empty_do_ids)} 条疾病记录缺少DO ID")
    else:
        print("所有疾病记录均有有效DO ID")

    # 创建RNA ID和疾病ID的映射
    rna_to_id = dict(zip(rna_df['rna'], rna_df['id']))
    disease_to_id = dict(zip(disease_df['disease'], disease_df['id']))

    # 构建关联矩阵 (初始化为0)
    association_matrix = np.zeros((len(unique_diseases), len(unique_rnas)), dtype=int)

    # 填充关联矩阵
    for _, row in human_df_valid.iterrows():
        rna = row['RNA Symbol']
        disease = row['Disease Name']

        if rna in rna_to_id and disease in disease_to_id:
            disease_idx = disease_to_id[disease] - 1  # 转换为0-based索引
            rna_idx = rna_to_id[rna] - 1  # 转换为0-based索引
            association_matrix[disease_idx][rna_idx] = 1

    # 计算关联总数
    total_associations = np.sum(association_matrix)
    print(f"RNA-疾病关联总数: {total_associations}")

    # 创建稀疏矩阵表示 (disease_id, rna_id, association)
    sparse_matrix = []
    for i in range(len(unique_diseases)):
        for j in range(len(unique_rnas)):
            if association_matrix[i][j] == 1:
                sparse_matrix.append([i + 1, j + 1, 1])

    sparse_df = pd.DataFrame(sparse_matrix, columns=['Disease ID', 'RNA ID', 'Association'])

    return rna_df, disease_df, association_matrix, sparse_df


def save_results(rna_df, disease_df, association_matrix, sparse_df, output_dir='.'):
    """
    保存处理结果到文件

    参数:
    rna_df (DataFrame): RNA数据
    disease_df (DataFrame): 疾病数据
    association_matrix (ndarray): 关联矩阵
    sparse_df (DataFrame): 稀疏矩阵表示
    output_dir (str): 输出目录
    """
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 保存RNA数据
    rna_path = os.path.join(output_dir, 'unique_rnas.csv')
    rna_df.to_csv(rna_path, index=False)
    print(f"RNA数据已保存到: {rna_path}")

    # 保存疾病数据
    disease_path = os.path.join(output_dir, 'unique_diseases.csv')
    disease_df.to_csv(disease_path, index=False)
    print(f"疾病数据已保存到: {disease_path}")

    # 保存稀疏关联矩阵
    sparse_path = os.path.join(output_dir, 'association_matrix_sparse.csv')
    sparse_df.to_csv(sparse_path, index=False)
    print(f"关联矩阵(稀疏格式)已保存到: {sparse_path}")

    # 保存完整关联矩阵
    full_matrix_path = os.path.join(output_dir, 'association_matrix_full.csv')

    # 创建完整矩阵的DataFrame
    disease_ids = disease_df['id'].tolist()
    disease_names = disease_df['disease'].tolist()

    # 生成列名 (RNA_1, RNA_2, ...)
    rna_columns = [f'RNA_{i}' for i in range(1, association_matrix.shape[1] + 1)]

    # 创建DataFrame
    full_matrix_df = pd.DataFrame(association_matrix, columns=rna_columns)
    full_matrix_df.insert(0, 'Disease Name', disease_names)
    full_matrix_df.insert(0, 'Disease ID', disease_ids)

    full_matrix_df.to_csv(full_matrix_path, index=False)
    print(f"完整关联矩阵已保存到: {full_matrix_path}")


def main():
    """主函数"""
    file_path = '../RNADiseasev4.0_RNA-disease_experiment_piRNA.xlsx'
    output_dir = 'output'

    # 处理数据
    rna_df, disease_df, association_matrix, sparse_df = process_rna_disease_data(file_path)

    # 保存结果
    save_results(rna_df, disease_df, association_matrix, sparse_df, output_dir)

    print("数据处理完成！")
    print(f"总共有 {len(rna_df)} 个不同的RNA")
    print(f"总共有 {len(disease_df)} 个不同的疾病")
    print(f"总共有 {np.sum(association_matrix)} 个RNA-疾病关联")


if __name__ == "__main__":
    main()