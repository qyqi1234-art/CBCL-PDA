import pandas as pd
import numpy as np
import requests
import csv
import os
import math
from collections import defaultdict


def load_disease_csv(file_path):
    """
    加载疾病CSV文件

    参数:
        file_path: CSV文件路径

    返回:
        DataFrame: 包含疾病信息的数据框
    """
    df = pd.read_csv(file_path)
    print(f"加载了 {len(df)} 种疾病")
    return df


def fetch_disease_ontology():
    """
    从GitHub获取Disease Ontology数据

    返回:
        str: OBO格式的内容
    """
    url = "https://raw.githubusercontent.com/DiseaseOntology/HumanDiseaseOntology/main/src/ontology/doid.obo"
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception(f"获取Disease Ontology失败，状态码：{response.status_code}")

    return response.text


def parse_obo(obo_text):
    """
    解析OBO格式的Disease Ontology数据

    参数:
        obo_text: OBO格式的文本

    返回:
        list: Terms列表，每个term是一个字典
    """
    terms = []
    current_term = None

    for line in obo_text.split('\n'):
        line = line.strip()

        # 忽略注释和空行
        if line.startswith('!') or line == '':
            continue

        # 开始一个新的term
        if line == '[Term]':
            if current_term is not None:
                terms.append(current_term)
            current_term = {
                'id': '',
                'name': '',
                'is_a': [],
                'alt_id': []
            }
            continue

        # 如果已经不在Term部分，保存当前Term
        if line.startswith('[') and not line.startswith('[Term]'):
            if current_term is not None:
                terms.append(current_term)
                current_term = None
            continue

        # 处理Term的属性
        if current_term is not None and ':' in line:
            tag, value = [p.strip() for p in line.split(':', 1)]

            if tag == 'id':
                current_term['id'] = value
            elif tag == 'name':
                current_term['name'] = value
            elif tag == 'is_a':
                # 提取关系，通常格式为 "DOID:123 ! disease name"
                is_a = value.split('!')[0].strip()
                current_term['is_a'].append(is_a)
            elif tag == 'alt_id':
                current_term['alt_id'].append(value)

    # 添加最后一个term
    if current_term is not None:
        terms.append(current_term)

    return terms


def build_disease_ontology_network(terms):
    """
    构建疾病本体网络

    参数:
        terms: 解析后的terms列表

    返回:
        tuple: (id_to_term, child_to_parents, parent_to_children)
    """
    # ID到Term的映射
    id_to_term = {}

    # 处理主ID和替代ID
    for term in terms:
        id_to_term[term['id']] = term
        for alt_id in term['alt_id']:
            id_to_term[alt_id] = term

    # 构建父子关系
    child_to_parents = defaultdict(list)
    parent_to_children = defaultdict(list)

    for term in terms:
        child_id = term['id']

        for parent_id in term['is_a']:
            child_to_parents[child_id].append(parent_id)
            parent_to_children[parent_id].append(child_id)

    return id_to_term, child_to_parents, parent_to_children


def get_all_ancestors(term_id, child_to_parents, visited=None):
    """
    获取一个term的所有祖先节点

    参数:
        term_id: Term的ID
        child_to_parents: 子到父级的映射
        visited: 已访问的节点集合

    返回:
        set: 所有祖先节点的集合
    """
    if visited is None:
        visited = set()

    if term_id in visited:
        return visited

    visited.add(term_id)

    for parent in child_to_parents[term_id]:
        get_all_ancestors(parent, child_to_parents, visited)

    return visited


def get_all_descendants(term_id, parent_to_children, visited=None):
    """
    获取一个term的所有后代节点

    参数:
        term_id: Term的ID
        parent_to_children: 父到子级的映射
        visited: 已访问的节点集合

    返回:
        set: 所有后代节点的集合
    """
    if visited is None:
        visited = set()

    if term_id in visited:
        return visited

    visited.add(term_id)

    for child in parent_to_children[term_id]:
        get_all_descendants(child, parent_to_children, visited)

    return visited


def calculate_information_content(terms, parent_to_children):
    """
    计算每个term的信息内容 (IC)

    参数:
        terms: 所有terms
        parent_to_children: 父到子的映射

    返回:
        dict: term_id到IC的映射
    """
    ic = {}
    total_terms = len(terms)

    for term in terms:
        term_id = term['id']
        descendants = get_all_descendants(term_id, parent_to_children)
        probability = len(descendants) / total_terms

        # IC(t) = -log(p(t))
        if probability > 0:
            ic[term_id] = -math.log(probability)
        else:
            ic[term_id] = 0

    return ic


def find_lca(term1, term2, child_to_parents, ic):
    """
    找到两个term的最近公共祖先 (LCA)

    参数:
        term1: 第一个term的ID
        term2: 第二个term的ID
        child_to_parents: 子到父的映射
        ic: 信息内容字典

    返回:
        str: LCA的ID
    """
    ancestors1 = get_all_ancestors(term1, child_to_parents)
    ancestors2 = get_all_ancestors(term2, child_to_parents)

    # 找出共同祖先
    common_ancestors = ancestors1.intersection(ancestors2)

    if not common_ancestors:
        # 如果没有共同祖先，返回根节点
        return "DOID:4"  # 'disease' is typically the root

    # 找出信息内容最高的祖先
    max_ic = -float('inf')
    lca = None

    for ancestor in common_ancestors:
        ancestor_ic = ic.get(ancestor, 0)
        if ancestor_ic > max_ic:
            max_ic = ancestor_ic
            lca = ancestor

    return lca


def calculate_lin_similarity(term1, term2, child_to_parents, ic):
    """
    计算两个term之间的Lin语义相似度

    参数:
        term1: 第一个term的ID
        term2: 第二个term的ID
        child_to_parents: 子到父的映射
        ic: 信息内容字典

    返回:
        float: Lin相似度值
    """
    if term1 == term2:
        return 1.0

    lca = find_lca(term1, term2, child_to_parents, ic)

    ic_lca = ic.get(lca, 0)
    ic_term1 = ic.get(term1, 0)
    ic_term2 = ic.get(term2, 0)

    denominator = ic_term1 + ic_term2
    if denominator == 0:
        return 0

    return (2 * ic_lca) / denominator


def build_similarity_matrix(disease_df, id_to_term, child_to_parents, ic):
    """
    构建疾病语义相似度矩阵

    参数:
        disease_df: 疾病数据框
        id_to_term: ID到Term的映射
        child_to_parents: 子到父的映射
        ic: 信息内容字典

    返回:
        tuple: (matrix, disease_ids, id_to_index)
    """
    # 筛选有效的DO ID
    valid_diseases = []
    for _, row in disease_df.iterrows():
        do_id = row.get('DO ID', '')
        if do_id and isinstance(do_id, str) and do_id.strip() and do_id in id_to_term:
            valid_diseases.append((row['id'], row['disease'], do_id))

    print(f"找到 {len(valid_diseases)} 个在本体中存在的疾病")

    if not valid_diseases:
        raise ValueError("没有找到有效的疾病ID")

    # 创建索引映射
    id_to_index = {}
    disease_ids = []
    disease_names = []

    for i, (_, disease, do_id) in enumerate(valid_diseases):
        id_to_index[do_id] = i
        disease_ids.append(do_id)
        disease_names.append(disease)

    # 初始化矩阵
    n = len(valid_diseases)
    matrix = np.zeros((n, n))

    # 填充相似度矩阵
    for i in range(n):
        for j in range(n):
            if i == j:
                matrix[i][j] = 1.0
            else:
                do_id1 = disease_ids[i]
                do_id2 = disease_ids[j]

                similarity = calculate_lin_similarity(do_id1, do_id2, child_to_parents, ic)
                matrix[i][j] = similarity

    return matrix, disease_ids, disease_names, id_to_index


def save_similarity_matrix(matrix, disease_ids, disease_names, output_file):
    """
    保存相似度矩阵到CSV文件

    参数:
        matrix: 相似度矩阵
        disease_ids: 疾病ID列表
        disease_names: 疾病名称列表
        output_file: 输出文件路径
    """
    n = len(disease_ids)

    # 创建带有标题行的矩阵
    header = [''] + [f"{disease_names[i]} ({disease_ids[i]})" for i in range(n)]

    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(header)

        for i in range(n):
            row = [f"{disease_names[i]} ({disease_ids[i]})"] + [f"{matrix[i][j]:.4f}" for j in range(n)]
            writer.writerow(row)


def main():
    # 创建输出目录
    output_dir = "output"
    os.makedirs(output_dir, exist_ok=True)

    # 加载疾病数据
    disease_df = load_disease_csv("./output/unique_diseases.csv")

    obo_text = fetch_disease_ontology()
    terms = parse_obo(obo_text)

    # 构建本体网络
    id_to_term, child_to_parents, parent_to_children = build_disease_ontology_network(terms)

    # 计算信息内容
    ic = calculate_information_content(terms, parent_to_children)

    # 构建相似度矩阵
    matrix, disease_ids, disease_names, id_to_index = build_similarity_matrix(
        disease_df, id_to_term, child_to_parents, ic
    )

    # 保存结果
    output_file = os.path.join(output_dir, "disSSimilarity.csv")
    save_similarity_matrix(matrix, disease_ids, disease_names, output_file)

    # 保存NumPy格式的矩阵和ID映射
    np_output_file = os.path.join(output_dir, "disSSimilarity.npz")
    np.savez(
        np_output_file,
        matrix=matrix,
        disease_ids=disease_ids,
        disease_names=disease_names
    )



if __name__ == "__main__":
    main()